$(document).ready(function(){ 
	$('#menu').dropotron({ offsetY: -5, mode: 'fade' });		
});
